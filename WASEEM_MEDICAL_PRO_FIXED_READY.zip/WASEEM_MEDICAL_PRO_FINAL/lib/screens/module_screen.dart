import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../providers/app_provider.dart';
import '../services/backup.dart';
import '../services/messaging.dart';
import '../services/pdf_service.dart';

class ModuleScreen extends StatefulWidget {
  final String title;
  final String type;

  const ModuleScreen({
    super.key,
    required this.title,
    required this.type,
  });

  @override
  State<ModuleScreen> createState() => _ModuleScreenState();
}

class _ModuleScreenState extends State<ModuleScreen> {
  bool get _canAdd =>
      !<String>['reports', 'messages', 'departments', 'settings']
          .contains(widget.type);

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      floatingActionButton: _canAdd
          ? FloatingActionButton.extended(
              onPressed: _add,
              icon: const Icon(Icons.add),
              label: const Text('إضافة'),
            )
          : null,
      body: _body(provider),
    );
  }

  Widget _body(AppProvider provider) {
    switch (widget.type) {
      case 'appointments':
        return _table(
          provider.appointments,
          'المواعيد',
          Icons.calendar_month,
        );
      case 'sessions':
        return _table(
          provider.sessions,
          'الجلسات',
          Icons.event_available,
        );
      case 'accounting':
        return _accounting(provider);
      case 'staff':
        return _table(provider.staff, 'الكادر والموظفون', Icons.badge);
      case 'inventory':
        return _table(
          provider.inventory,
          'المخزون',
          Icons.inventory_2,
        );
      case 'reports':
        return _reports(provider);
      case 'messages':
        return _messages(provider);
      case 'departments':
        return _departments();
      case 'settings':
        return _settings(provider);
      default:
        return const Center(child: Text('لا توجد بيانات'));
    }
  }

  Widget _table(
    List<Map<String, dynamic>> data,
    String emptyTitle,
    IconData icon,
  ) {
    if (data.isEmpty) {
      return Center(child: Text('لا توجد سجلات في $emptyTitle'));
    }

    return ListView.builder(
      padding: const EdgeInsets.all(10),
      itemCount: data.length,
      itemBuilder: (_, int index) {
        final row = data[index];
        final title = row['name'] ??
            row['patient_name'] ??
            row['package_name'] ??
            row['description'] ??
            'سجل';

        String subtitle = '';
        if (row['date'] != null) {
          subtitle =
              '${row['date']} ${row['time'] ?? ''} • ${row['status'] ?? ''}';
        } else if (row['role'] != null) {
          subtitle = '${row['role']} • ${row['phone'] ?? ''}';
        } else if (row['barcode'] != null) {
          subtitle =
              'الكمية: ${row['quantity'] ?? 0} • باركود: ${row['barcode']}';
        }

        return Card(
          child: ListTile(
            leading: CircleAvatar(child: Icon(icon)),
            title: Text('$title'),
            subtitle: Text(subtitle),
          ),
        );
      },
    );
  }

  Future<void> _add() async {
    final provider = context.read<AppProvider>();
    final date = DateFormat('yyyy-MM-dd').format(DateTime.now());

    if (widget.type == 'appointments') {
      final patient = await _pickPatient(provider);
      if (patient == null) return;

      final time = await _ask('وقت الموعد', '10:00');
      if (time == null) return;

      await provider.addAppointment(<String, dynamic>{
        'patient_id': patient['id'],
        'patient_name': patient['name'],
        'date': date,
        'time': time,
        'doctor': patient['doctor'] ?? '',
        'service': patient['service'] ?? '',
        'status': 'مجدول',
        'notes': '',
        'created_at': DateTime.now().toIso8601String(),
      });
    } else if (widget.type == 'sessions') {
      final patient = await _pickPatient(provider);
      if (patient == null) return;

      await provider.addSession(<String, dynamic>{
        'patient_id': patient['id'],
        'patient_name': patient['name'],
        'package_name': 'باقة علاج',
        'session_no': 1,
        'total_sessions': 10,
        'date': date,
        'status': 'مجدولة',
        'therapist': '',
        'notes': '',
        'created_at': DateTime.now().toIso8601String(),
      });
    } else if (widget.type == 'staff') {
      final name = await _ask('اسم الموظف', '');
      if (name == null || name.trim().isEmpty) return;

      final role = await _ask('الوظيفة', '');
      await provider.addStaff(<String, dynamic>{
        'name': name.trim(),
        'role': role ?? '',
        'specialty': '',
        'phone': '',
        'salary': 0,
        'active': 1,
        'notes': '',
      });
    } else if (widget.type == 'inventory') {
      final name = await _ask('اسم الصنف', '');
      if (name == null || name.trim().isEmpty) return;

      final quantity = await _ask('الكمية', '0');
      await provider.addInventory(<String, dynamic>{
        'name': name.trim(),
        'barcode': '',
        'unit': 'قطعة',
        'quantity': double.tryParse(quantity ?? '0') ?? 0,
        'carton_qty': 0,
        'piece_per_carton': 1,
        'cost_piece': 0,
        'cost_carton': 0,
        'min_quantity': 0,
      });
    }
  }

  Future<Map<String, dynamic>?> _pickPatient(
    AppProvider provider,
  ) {
    return showDialog<Map<String, dynamic>>(
      context: context,
      builder: (BuildContext dialogContext) {
        if (provider.patients.isEmpty) {
          return const AlertDialog(
            title: Text('اختر المريض'),
            content: Text('لا يوجد مرضى مسجلون.'),
          );
        }

        return AlertDialog(
          title: const Text('اختر المريض'),
          content: SizedBox(
            width: 360,
            height: 360,
            child: ListView.builder(
              itemCount: provider.patients.length,
              itemBuilder: (_, int index) {
                final patient = provider.patients[index];
                return ListTile(
                  title: Text('${patient['name'] ?? ''}'),
                  subtitle: Text('${patient['file_no'] ?? ''}'),
                  onTap: () => Navigator.pop(dialogContext, patient),
                );
              },
            ),
          ),
        );
      },
    );
  }

  Future<String?> _ask(String title, String initialValue) {
    return showDialog<String>(
      context: context,
      builder: (BuildContext dialogContext) {
        final controller = TextEditingController(text: initialValue);

        return AlertDialog(
          title: Text(title),
          content: TextField(
            controller: controller,
            autofocus: true,
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () =>
                  Navigator.pop(dialogContext, controller.text),
              child: const Text('حفظ'),
            ),
          ],
        );
      },
    );
  }

  Widget _accounting(AppProvider provider) {
    return FutureBuilder<Map<String, double>>(
      future: provider.financialSummary(),
      builder: (BuildContext context, AsyncSnapshot<Map<String, double>> snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final values = snapshot.data!;

        return ListView(
          padding: const EdgeInsets.all(12),
          children: <Widget>[
            _money('إجمالي الفواتير', values['invoices'] ?? 0),
            _money('المقبوضات', values['receipts'] ?? 0),
            _money('المصروفات', values['expenses'] ?? 0),
            _money('المتبقي', values['outstanding'] ?? 0),
            const SizedBox(height: 10),
            const Text(
              'القيود الأساسية',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
            ),
            const ListTile(
              title: Text('فاتورة'),
              subtitle: Text('مدين: ذمم المرضى — دائن: إيرادات الخدمات'),
            ),
            const ListTile(
              title: Text('قبض'),
              subtitle: Text('مدين: الصندوق — دائن: ذمم المرضى'),
            ),
            const ListTile(
              title: Text('مصروف'),
              subtitle: Text('مدين: المصروف — دائن: الصندوق'),
            ),
            FilledButton.icon(
              onPressed: () => _invoice(provider),
              icon: const Icon(Icons.receipt_long),
              label: const Text('إنشاء فاتورة'),
            ),
            FilledButton.icon(
              onPressed: () => _expense(provider),
              icon: const Icon(Icons.payments),
              label: const Text('تسجيل مصروف'),
            ),
          ],
        );
      },
    );
  }

  Widget _money(String title, double value) {
    return Card(
      child: ListTile(
        title: Text(title),
        trailing: Text(
          value.toStringAsFixed(2),
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Future<void> _invoice(AppProvider provider) async {
    final patient = await _pickPatient(provider);
    if (patient == null) return;

    final total =
        double.tryParse(await _ask('إجمالي الفاتورة', '0') ?? '0') ?? 0;
    final paid =
        double.tryParse(await _ask('المدفوع', '0') ?? '0') ?? 0;

    if (total <= 0 || paid < 0 || paid > total) return;

    await provider.addInvoice(<String, dynamic>{
      'invoice_no': provider.no('INV'),
      'patient_id': patient['id'],
      'patient_name': patient['name'],
      'date': DateFormat('yyyy-MM-dd').format(DateTime.now()),
      'description': 'خدمة طبية',
      'total': total,
      'paid': paid,
      'status': paid >= total ? 'مدفوعة' : 'مفتوحة',
    });
  }

  Future<void> _expense(AppProvider provider) async {
    final description = await _ask('وصف المصروف', '');
    if (description == null || description.trim().isEmpty) return;

    final amount =
        double.tryParse(await _ask('المبلغ', '0') ?? '0') ?? 0;
    if (amount <= 0) return;

    await provider.addExpense(<String, dynamic>{
      'expense_no': provider.no('EXP'),
      'category': 'عام',
      'description': description.trim(),
      'date': DateFormat('yyyy-MM-dd').format(DateTime.now()),
      'amount': amount,
      'payment_method': 'نقدي',
      'notes': '',
    });
  }

  Widget _reports(AppProvider provider) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: <Widget>[
        _report(
          'المرضى',
          'عدد السجلات: ${provider.patients.length}',
          () => PdfService.printReport(
            'تقرير المرضى',
            <String>['عدد المرضى: ${provider.patients.length}'],
          ),
        ),
        _report(
          'المواعيد',
          'عدد السجلات: ${provider.appointments.length}',
          () => PdfService.printReport(
            'تقرير المواعيد',
            <String>['عدد المواعيد: ${provider.appointments.length}'],
          ),
        ),
        _report(
          'الجلسات',
          'عدد السجلات: ${provider.sessions.length}',
          () => PdfService.printReport(
            'تقرير الجلسات',
            <String>['عدد الجلسات: ${provider.sessions.length}'],
          ),
        ),
        _report(
          'التقرير المالي',
          'فواتير ومقبوضات ومصروفات',
          () async {
            final values = await provider.financialSummary();
            await PdfService.printReport(
              'التقرير المالي',
              <String>[
                'الفواتير: ${(values['invoices'] ?? 0).toStringAsFixed(2)}',
                'المقبوضات: ${(values['receipts'] ?? 0).toStringAsFixed(2)}',
                'المصروفات: ${(values['expenses'] ?? 0).toStringAsFixed(2)}',
                'المتبقي: ${(values['outstanding'] ?? 0).toStringAsFixed(2)}',
              ],
            );
          },
        ),
      ],
    );
  }

  Widget _report(String title, String subtitle, VoidCallback onPressed) {
    return Card(
      child: ListTile(
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: IconButton(
          onPressed: onPressed,
          icon: const Icon(Icons.print),
        ),
      ),
    );
  }

  Widget _messages(AppProvider provider) {
    if (provider.patients.isEmpty) {
      return const Center(child: Text('أضف مرضى أولًا'));
    }

    return ListView(
      padding: const EdgeInsets.all(10),
      children: <Widget>[
        const Padding(
          padding: EdgeInsets.all(8),
          child: Text(
            'مركز الرسائل اليدوية',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
        ...provider.patients.map(
          (Map<String, dynamic> patient) {
            final message = MessagingService.template(
              'registration',
              <String, String>{
                'name': '${patient['name'] ?? ''}',
                'file': '${patient['file_no'] ?? ''}',
              },
            );

            return Card(
              child: ListTile(
                title: Text('${patient['name'] ?? ''}'),
                subtitle: Text(
                  '${patient['file_no'] ?? ''} • ${patient['phone'] ?? ''}',
                ),
                trailing: Wrap(
                  children: <Widget>[
                    IconButton(
                      onPressed: () => MessagingService.whatsapp(
                        '${patient['phone'] ?? ''}',
                        message,
                      ),
                      icon: const Icon(Icons.chat),
                      tooltip: 'WhatsApp',
                    ),
                    IconButton(
                      onPressed: () => MessagingService.sms(
                        '${patient['phone'] ?? ''}',
                        message,
                      ),
                      icon: const Icon(Icons.sms),
                      tooltip: 'رسالة SMS',
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _departments() {
    const departments = <String>[
      'الأطفال',
      'النساء',
      'الرجال',
      'الحجامة والمساج',
      'الصالة الرياضية',
      'التغذية العلاجية — د. غمدان أحمد قاسم الجماعي — الأربعاء والخميس',
      'المخ والأعصاب — يوم واحد شهريًا حسب الحجز',
    ];

    return ListView(
      children: departments
          .map(
            (String item) => ListTile(
              leading: const Icon(Icons.folder_special),
              title: Text(item),
            ),
          )
          .toList(),
    );
  }

  Widget _settings(AppProvider provider) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: <Widget>[
        const ListTile(
          title: Text('اسم المركز'),
          subtitle: Text('وسيم ميديكال'),
        ),
        const ListTile(
          title: Text('اسم النظام'),
          subtitle: Text('WASEEM MEDICAL PRO'),
        ),
        const ListTile(
          title: Text('الدعم'),
          subtitle: Text('774486588'),
        ),
        SwitchListTile(
          value: provider.darkMode,
          onChanged: (_) => provider.toggleDark(),
          title: const Text('الوضع الليلي'),
        ),
        ListTile(
          leading: const Icon(Icons.backup),
          title: const Text('إنشاء نسخة احتياطية'),
          onTap: () async {
            final data = <String, List<Map<String, dynamic>>>{};
            const tables = <String>[
              'patients',
              'appointments',
              'sessions',
              'packages',
              'invoices',
              'receipts',
              'expenses',
              'staff',
              'inventory',
              'accounts',
              'journal_entries',
              'journal_lines',
            ];

            for (final table in tables) {
              data[table] = await provider.db.query(table);
            }

            final file = await BackupService.createBackup(data);
            await BackupService.share(file);
          },
        ),
        ListTile(
          leading: const Icon(Icons.print),
          title: const Text('اختبار الطباعة'),
          onTap: () => PdfService.printReport(
            'وسيم ميديكال',
            const <String>[
              'اختبار طباعة ناجح',
              'الدعم: 774486588',
            ],
          ),
        ),
      ],
    );
  }
}
