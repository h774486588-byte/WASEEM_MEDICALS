import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_provider.dart';
import '../services/messaging.dart';
import 'add_patient_screen.dart';

class PatientsScreen extends StatefulWidget {
  const PatientsScreen({super.key});

  @override
  State<PatientsScreen> createState() => _PatientsState();
}

class _PatientsState extends State<PatientsScreen> {
  final TextEditingController _query = TextEditingController();
  List<Map<String, dynamic>> _rows = <Map<String, dynamic>>[];

  @override
  void initState() {
    super.initState();
    final provider = context.read<AppProvider>();
    _rows = List<Map<String, dynamic>>.from(provider.patients);
    _query.addListener(_search);
  }

  Future<void> _search() async {
    final provider = context.read<AppProvider>();
    final result = await provider.searchPatients(_query.text);
    if (!mounted) return;
    setState(() => _rows = result);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();

    if (_query.text.isEmpty) {
      _rows = provider.patients;
    }

    return Scaffold(
      appBar: AppBar(title: const Text('المرضى')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => const AddPatientScreen(),
            ),
          );
        },
        icon: const Icon(Icons.person_add),
        label: const Text('مريض جديد'),
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _query,
              decoration: const InputDecoration(
                labelText: 'بحث بالاسم أو الهاتف أو رقم الملف',
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: _rows.isEmpty
                ? const Center(child: Text('لا توجد سجلات'))
                : ListView.builder(
                    itemCount: _rows.length,
                    itemBuilder: (BuildContext context, int index) {
                      final patient = _rows[index];
                      return Card(
                        child: ListTile(
                          leading: const CircleAvatar(
                            child: Icon(Icons.person),
                          ),
                          title: Text('${patient['name'] ?? ''}'),
                          subtitle: Text(
                            '${patient['file_no'] ?? ''} • ${patient['phone'] ?? ''}',
                          ),
                          onTap: () => _actions(context, provider, patient),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _actions(
    BuildContext context,
    AppProvider provider,
    Map<String, dynamic> patient,
  ) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (BuildContext sheetContext) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.person),
                title: const Text('فتح الملف'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _view(context, patient);
                },
              ),
              ListTile(
                leading: const Icon(Icons.calendar_month),
                title: const Text('موعد جديد'),
                onTap: () async {
                  Navigator.pop(sheetContext);
                  await provider.addAppointment(<String, dynamic>{
                    'patient_id': patient['id'],
                    'patient_name': patient['name'],
                    'date': DateTime.now().toIso8601String().substring(0, 10),
                    'time': '10:00',
                    'doctor': patient['doctor'] ?? '',
                    'service': patient['service'] ?? '',
                    'status': 'مجدول',
                    'notes': '',
                    'created_at': DateTime.now().toIso8601String(),
                  });
                },
              ),
              ListTile(
                leading: const Icon(Icons.chat),
                title: const Text('رسالة WhatsApp'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  MessagingService.whatsapp(
                    '${patient['phone'] ?? ''}',
                    MessagingService.template(
                      'registration',
                      <String, String>{
                        'name': '${patient['name'] ?? ''}',
                        'file': '${patient['file_no'] ?? ''}',
                      },
                    ),
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _view(BuildContext context, Map<String, dynamic> patient) {
    final lines = <String>[
      'رقم الملف: ${patient['file_no'] ?? ''}',
      'الهاتف: ${patient['phone'] ?? ''}',
      'الجنس: ${patient['gender'] ?? ''}',
      'العمر: ${patient['age'] ?? ''}',
      'القسم: ${patient['department'] ?? ''}',
      'الخدمة: ${patient['service'] ?? ''}',
      'الطبيب/الأخصائي: ${patient['doctor'] ?? ''}',
      'الملاحظات: ${patient['notes'] ?? ''}',
    ];

    showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text('${patient['name'] ?? ''}'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: lines
                  .map(
                    (String line) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 5),
                      child: Text(line),
                    ),
                  )
                  .toList(),
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('إغلاق'),
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _query.removeListener(_search);
    _query.dispose();
    super.dispose();
  }
}
