import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_provider.dart';
import '../services/messaging.dart';

class AddPatientScreen extends StatefulWidget {
  const AddPatientScreen({super.key});

  @override
  State<AddPatientScreen> createState() => _AddPatientState();
}

class _AddPatientState extends State<AddPatientScreen> {
  final _formKey = GlobalKey<FormState>();

  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _age = TextEditingController();
  final _address = TextEditingController();
  final _service = TextEditingController(text: 'كشف/استشارة');
  final _doctor = TextEditingController();
  final _notes = TextEditingController();

  String _gender = 'ذكر';
  String _department = 'الأطفال';
  bool _prepareMessage = false;
  bool _saving = false;

  static const List<String> _departments = <String>[
    'الأطفال',
    'النساء',
    'الرجال',
    'الحجامة والمساج',
    'الصالة الرياضية',
    'التغذية العلاجية',
    'المخ والأعصاب',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة مريض جديد')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(14),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          children: <Widget>[
            _field(
              controller: _name,
              label: 'الاسم الكامل',
              required: true,
              textCapitalization: TextCapitalization.words,
            ),
            _field(
              controller: _phone,
              label: 'رقم الهاتف',
              keyboardType: TextInputType.phone,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  child: _field(
                    controller: _age,
                    label: 'العمر',
                    keyboardType: TextInputType.number,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _gender,
                    decoration: const InputDecoration(labelText: 'الجنس'),
                    items: const <String>['ذكر', 'أنثى']
                        .map(
                          (String value) => DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          ),
                        )
                        .toList(),
                    onChanged: (String? value) {
                      if (value == null) return;
                      setState(() => _gender = value);
                    },
                  ),
                ),
              ],
            ),
            _field(controller: _address, label: 'العنوان'),
            DropdownButtonFormField<String>(
              value: _department,
              decoration: const InputDecoration(labelText: 'القسم'),
              items: _departments
                  .map(
                    (String value) => DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    ),
                  )
                  .toList(),
              onChanged: (String? value) {
                if (value == null) return;
                setState(() => _department = value);
              },
            ),
            const SizedBox(height: 12),
            _field(controller: _service, label: 'الخدمة'),
            _field(controller: _doctor, label: 'الطبيب/الأخصائي'),
            _field(controller: _notes, label: 'الملاحظات', maxLines: 4),
            const SizedBox(height: 4),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: _prepareMessage,
              onChanged: (bool value) {
                setState(() => _prepareMessage = value);
              },
              title: const Text('تجهيز رسالة بعد الحفظ'),
              subtitle: const Text('تُفتح المحادثة في واتساب العادي بعد الحفظ'),
            ),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: _saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.save),
              label: Text(_saving ? 'جارٍ الحفظ...' : 'حفظ المريض'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final provider = context.read<AppProvider>();
    final patientName = _name.text.trim();
    final patientPhone = _phone.text.trim();
    final fileNo = provider.fileNo();

    setState(() => _saving = true);

    try {
      final data = <String, dynamic>{
        'file_no': fileNo,
        'name': patientName,
        'phone': patientPhone,
        'gender': _gender,
        'age': int.tryParse(_age.text.trim()),
        'address': _address.text.trim(),
        'case_type': '',
        'department': _department,
        'service': _service.text.trim(),
        'doctor': _doctor.text.trim(),
        'registered_at': DateTime.now().toIso8601String(),
        'notes': _notes.text.trim(),
        'active': 1,
      };

      await provider.addPatient(data);

      if (_prepareMessage && patientPhone.isNotEmpty) {
        await MessagingService.whatsapp(
          patientPhone,
          MessagingService.template(
            'registration',
            <String, String>{
              'name': patientName,
              'file': fileNo,
            },
          ),
        );
      }

      if (!mounted) return;
      Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر حفظ المريض: $e')),
      );
      setState(() => _saving = false);
    }
  }

  Widget _field({
    required TextEditingController controller,
    required String label,
    bool required = false,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
    TextCapitalization textCapitalization = TextCapitalization.none,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        maxLines: maxLines,
        keyboardType: keyboardType,
        textCapitalization: textCapitalization,
        decoration: InputDecoration(labelText: label),
        validator: required
            ? (String? value) {
                if (value == null || value.trim().isEmpty) {
                  return 'هذا الحقل مطلوب';
                }
                return null;
              }
            : null,
      ),
    );
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _age.dispose();
    _address.dispose();
    _service.dispose();
    _doctor.dispose();
    _notes.dispose();
    super.dispose();
  }
}
