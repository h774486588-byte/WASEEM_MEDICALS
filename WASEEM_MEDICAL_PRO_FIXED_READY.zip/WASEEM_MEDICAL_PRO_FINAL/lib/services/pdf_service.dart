import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class PdfService {
  static Future<pw.Font> _font() async {
    final data = await rootBundle.load(
      'assets/fonts/NotoSansArabic-Regular.ttf',
    );
    return pw.Font.ttf(data);
  }

  static Future<void> printReport(
    String title,
    List<String> lines,
  ) async {
    await Printing.layoutPdf(
      onLayout: (format) async {
        final font = await _font();
        final doc = pw.Document();

        doc.addPage(
          pw.Page(
            pageFormat: format,
            build: (_) {
              return pw.Directionality(
                textDirection: pw.TextDirection.rtl,
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.stretch,
                  children: <pw.Widget>[
                    pw.Text(
                      title,
                      style: pw.TextStyle(
                        font: font,
                        fontSize: 22,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    pw.SizedBox(height: 16),
                    ...lines.map(
                      (String line) => pw.Padding(
                        padding: const pw.EdgeInsets.all(6),
                        child: pw.Text(
                          line,
                          style: pw.TextStyle(font: font),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        );

        return doc.save();
      },
    );
  }

  static Future<File> saveReport(
    String title,
    List<String> lines,
  ) async {
    final font = await _font();
    final directory = await getApplicationDocumentsDirectory();
    final file = File(
      '${directory.path}/report_${DateTime.now().millisecondsSinceEpoch}.pdf',
    );
    final doc = pw.Document();

    doc.addPage(
      pw.Page(
        build: (_) {
          return pw.Directionality(
            textDirection: pw.TextDirection.rtl,
            child: pw.Column(
              children: <pw.Widget>[
                pw.Text(
                  title,
                  style: pw.TextStyle(font: font),
                ),
                ...lines.map(
                  (String line) => pw.Text(
                    line,
                    style: pw.TextStyle(font: font),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );

    await file.writeAsBytes(await doc.save());
    return file;
  }
}
