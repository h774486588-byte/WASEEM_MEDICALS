import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._();
  DatabaseHelper._();
  Database? _db;

  Future<Database> get db async => _db ??= await _open();

  Future<Database> _open() async {
    final dir = await getDatabasesPath();
    return openDatabase(join(dir, 'waseem_medical_pro.db'), version: 1, onCreate: _create);
  }

  Future<void> _create(Database db, int version) async {
    await db.execute('''CREATE TABLE patients (
      id INTEGER PRIMARY KEY AUTOINCREMENT, file_no TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
      phone TEXT, gender TEXT, age INTEGER, address TEXT, case_type TEXT, department TEXT,
      service TEXT, doctor TEXT, registered_at TEXT, notes TEXT, active INTEGER DEFAULT 1)''');
    await db.execute('''CREATE TABLE appointments (
      id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id INTEGER, patient_name TEXT, date TEXT,
      time TEXT, doctor TEXT, service TEXT, status TEXT, notes TEXT, created_at TEXT)''');
    await db.execute('''CREATE TABLE sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id INTEGER, patient_name TEXT, package_name TEXT,
      session_no INTEGER, total_sessions INTEGER, date TEXT, status TEXT, therapist TEXT,
      notes TEXT, transaction_id TEXT UNIQUE, created_at TEXT)''');
    await db.execute('''CREATE TABLE packages (
      id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id INTEGER, patient_name TEXT, name TEXT,
      total_sessions INTEGER, used_sessions INTEGER DEFAULT 0, price REAL DEFAULT 0,
      start_date TEXT, end_date TEXT, status TEXT)''');
    await db.execute('''CREATE TABLE invoices (
      id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT UNIQUE, patient_id INTEGER,
      patient_name TEXT, date TEXT, description TEXT, total REAL, paid REAL DEFAULT 0,
      status TEXT)''');
    await db.execute('''CREATE TABLE receipts (
      id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_no TEXT UNIQUE, patient_id INTEGER,
      patient_name TEXT, date TEXT, amount REAL, method TEXT, notes TEXT)''');
    await db.execute('''CREATE TABLE expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT, expense_no TEXT UNIQUE, category TEXT,
      description TEXT, date TEXT, amount REAL, payment_method TEXT, notes TEXT)''');
    await db.execute('''CREATE TABLE staff (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, role TEXT, specialty TEXT,
      phone TEXT, salary REAL DEFAULT 0, active INTEGER DEFAULT 1, notes TEXT)''');
    await db.execute('''CREATE TABLE inventory (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, barcode TEXT, unit TEXT,
      quantity REAL DEFAULT 0, carton_qty REAL DEFAULT 0, piece_per_carton REAL DEFAULT 1,
      cost_piece REAL DEFAULT 0, cost_carton REAL DEFAULT 0, min_quantity REAL DEFAULT 0)''');
    await db.execute('''CREATE TABLE accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, name TEXT NOT NULL,
      type TEXT, parent_id INTEGER, debit REAL DEFAULT 0, credit REAL DEFAULT 0)''');
    await db.execute('''CREATE TABLE journal_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT, entry_no TEXT UNIQUE, date TEXT,
      description TEXT, reference_type TEXT, reference_id INTEGER)''');
    await db.execute('''CREATE TABLE journal_lines (
      id INTEGER PRIMARY KEY AUTOINCREMENT, entry_id INTEGER, account_id INTEGER,
      debit REAL DEFAULT 0, credit REAL DEFAULT 0, description TEXT)''');
    await db.execute('''CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT)''');
    await _seed(db);
  }

  Future<void> _seed(Database db) async {
    final accounts = [
      ['1000','الأصول','asset'],['1100','الصندوق','asset'],['1200','البنوك','asset'],
      ['1300','ذمم المرضى','asset'],['2000','الالتزامات','liability'],['2100','الموردون','liability'],
      ['3000','حقوق الملكية','equity'],['4000','الإيرادات','income'],['4100','إيرادات الخدمات','income'],
      ['5000','المصروفات','expense'],['5100','الرواتب','expense'],['5200','المشتريات والمستلزمات','expense']
    ];
    for (final a in accounts) {
      await db.insert('accounts', {'code':a[0], 'name':a[1], 'type':a[2]}, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
    await db.insert('settings', {'key':'center_name','value':'وسيم ميديكال'}, conflictAlgorithm: ConflictAlgorithm.ignore);
    await db.insert('settings', {'key':'support','value':'774486588'}, conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  Future<List<Map<String,dynamic>>> query(String table, {String? where, List<Object?>? args, String? orderBy}) async =>
      (await db).query(table, where: where, whereArgs: args, orderBy: orderBy);
  Future<int> insert(String table, Map<String,dynamic> values) async => (await db).insert(table, values);
  Future<int> update(String table, Map<String,dynamic> values, int id) async =>
      (await db).update(table, values, where:'id=?', whereArgs:[id]);
  Future<int> delete(String table, int id) async => (await db).delete(table, where:'id=?', whereArgs:[id]);
  Future<int> count(String table) async => Sqflite.firstIntValue(await (await db).rawQuery('SELECT COUNT(*) FROM $table')) ?? 0;
  Future<void> close() async { final d = await db; await d.close(); _db = null; }
}
