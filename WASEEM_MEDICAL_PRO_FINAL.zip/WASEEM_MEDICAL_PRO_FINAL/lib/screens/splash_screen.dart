import 'dart:async';
import 'package:flutter/material.dart';
import '../core/app_config.dart';
import 'home_screen.dart';
class SplashScreen extends StatefulWidget{const SplashScreen({super.key}); @override State<SplashScreen> createState()=>_SplashState();}
class _SplashState extends State<SplashScreen>{@override void initState(){super.initState();Timer(const Duration(milliseconds:1300),(){if(mounted)Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const HomeScreen()));});}
@override Widget build(BuildContext c)=>Scaffold(body:Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Container(width:110,height:110,decoration:BoxDecoration(shape:BoxShape.circle,color:Theme.of(c).colorScheme.primaryContainer),child:Icon(Icons.local_hospital,size:60,color:Theme.of(c).colorScheme.primary)),const SizedBox(height:22),Text(AppConfig.appName,style:const TextStyle(fontSize:30,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text(AppConfig.appNameEn,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w600)),const SizedBox(height:8),const Text('نظام طبي وإداري ومحاسبي متكامل'),const SizedBox(height:18),Text('الدعم: ${AppConfig.supportPhone}'),const SizedBox(height:28),const CircularProgressIndicator()]))) ;}
}
