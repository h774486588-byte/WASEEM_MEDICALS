import 'package:url_launcher/url_launcher.dart';

class MessagingService {
  static String template(String type, Map<String,String> v) {
    final n=v['name']??''; final file=v['file']??''; final date=v['date']??''; final time=v['time']??'';
    switch(type){
      case 'appointment': return 'مرحبًا $n، نؤكد موعدكم في وسيم ميديكال بتاريخ $date الساعة $time. رقم الملف: $file.';
      case 'receipt': return 'مرحبًا $n، تم تسجيل سند قبض بالمبلغ ${v['amount']??''}. شكرًا لكم.';
      case 'package': return 'مرحبًا $n، تبقت لكم ${v['remaining']??''} جلسات من الباقة.';
      default: return 'مرحبًا $n، تم تسجيل ملفكم الطبي في وسيم ميديكال. رقم الملف: $file.';
    }
  }
  static Future<void> whatsapp(String phone,String text) async { final p=phone.replaceAll(RegExp(r'[^0-9+]'), ''); final uri=Uri.parse('https://wa.me/$p?text=${Uri.encodeComponent(text)}'); await launchUrl(uri,mode:LaunchMode.externalApplication); }
  static Future<void> sms(String phone,String text) async { final uri=Uri.parse('sms:${phone.replaceAll(RegExp(r'[^0-9+]'), '')}?body=${Uri.encodeComponent(text)}'); await launchUrl(uri,mode:LaunchMode.externalApplication); }
}
