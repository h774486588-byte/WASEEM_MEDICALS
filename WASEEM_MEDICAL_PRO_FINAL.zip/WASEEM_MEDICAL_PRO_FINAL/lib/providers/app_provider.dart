import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/database.dart';

class AppProvider extends ChangeNotifier {
  final DatabaseHelper db = DatabaseHelper.instance;
  bool darkMode = false;
  bool busy = false;
  List<Map<String,dynamic>> patients = [], appointments = [], sessions = [], packages = [], invoices = [], receipts = [], expenses = [], staff = [], inventory = [];

  Future<void> init() async { final p = await SharedPreferences.getInstance(); darkMode = p.getBool('dark') ?? false; await loadAll(); }
  Future<void> loadAll() async { busy = true; notifyListeners();
    patients = await db.query('patients', orderBy:'id DESC'); appointments = await db.query('appointments', orderBy:'id DESC');
    sessions = await db.query('sessions', orderBy:'id DESC'); packages = await db.query('packages', orderBy:'id DESC');
    invoices = await db.query('invoices', orderBy:'id DESC'); receipts = await db.query('receipts', orderBy:'id DESC');
    expenses = await db.query('expenses', orderBy:'id DESC'); staff = await db.query('staff', orderBy:'id DESC'); inventory = await db.query('inventory', orderBy:'id DESC');
    busy = false; notifyListeners(); }
  Future<void> toggleDark() async { darkMode = !darkMode; final p = await SharedPreferences.getInstance(); await p.setBool('dark', darkMode); notifyListeners(); }
  String fileNo() => 'P-${DateTime.now().millisecondsSinceEpoch.toString().substring(6)}';
  String no(String prefix) => '$prefix-${DateTime.now().millisecondsSinceEpoch}';
  Future<void> addPatient(Map<String,dynamic> x) async { await db.insert('patients', x); await loadAll(); }
  Future<void> updatePatient(int id, Map<String,dynamic> x) async { await db.update('patients', x, id); await loadAll(); }
  Future<void> addAppointment(Map<String,dynamic> x) async { await db.insert('appointments', x); await loadAll(); }
  Future<void> addSession(Map<String,dynamic> x) async { x['transaction_id'] ??= no('SES'); await db.insert('sessions', x); await loadAll(); }
  Future<void> addPackage(Map<String,dynamic> x) async { await db.insert('packages', x); await loadAll(); }
  Future<void> addInvoice(Map<String,dynamic> x) async {
    final id = await db.insert('invoices', x); final total = (x['total'] as num?)?.toDouble() ?? 0; final paid = (x['paid'] as num?)?.toDouble() ?? 0;
    await _journal('فاتورة ${x['invoice_no']}', 'invoice', id, [['1300', total, 0],['4100',0,total]]);
    if (paid > 0) await addReceipt({'patient_id':x['patient_id'],'patient_name':x['patient_name'],'receipt_no':no('REC'),'date':x['date'],'amount':paid,'method':'نقدي','notes':'دفعة مرتبطة بالفاتورة'});
    await loadAll(); }
  Future<void> addReceipt(Map<String,dynamic> x) async { final id = await db.insert('receipts', x); final amount=(x['amount'] as num?)?.toDouble() ?? 0; if(amount>0) await _journal('سند قبض ${x['receipt_no']}','receipt',id,[['1100',amount,0],['1300',0,amount]]); await loadAll(); }
  Future<void> addExpense(Map<String,dynamic> x) async { final id=await db.insert('expenses',x); final amount=(x['amount'] as num?)?.toDouble() ?? 0; await _journal('مصروف ${x['expense_no']}','expense',id,[['5100',amount,0],['1100',0,amount]]); await loadAll(); }
  Future<void> addStaff(Map<String,dynamic> x) async { await db.insert('staff', x); await loadAll(); }
  Future<void> addInventory(Map<String,dynamic> x) async { await db.insert('inventory', x); await loadAll(); }
  Future<void> _journal(String desc,String ref,int refId,List<List<Object>> lines) async {
    final debit=lines.fold<double>(0,(s,l)=>s+(l[1] as num).toDouble()); final credit=lines.fold<double>(0,(s,l)=>s+(l[2] as num).toDouble());
    if ((debit-credit).abs()>0.0001) throw Exception('القيد غير متوازن');
    final eid=await db.insert('journal_entries',{'entry_no':no('JE'),'date':DateTime.now().toIso8601String(),'description':desc,'reference_type':ref,'reference_id':refId});
    final accounts=await db.query('accounts');
    for(final l in lines){final code=l[0] as String; final a=accounts.where((r)=>r['code']==code).toList(); if(a.isNotEmpty) await db.insert('journal_lines',{'entry_id':eid,'account_id':a.first['id'],'debit':l[1],'credit':l[2],'description':desc});}
  }
  Future<Map<String,double>> financialSummary() async {
    double sum(String field,List<Map<String,dynamic>> rows)=>rows.fold(0,(s,r)=>s+((r[field] as num?)?.toDouble() ?? 0));
    return {'invoices':sum('total',invoices),'receipts':sum('amount',receipts),'expenses':sum('amount',expenses),'outstanding':sum('total',invoices)-sum('paid',invoices)};
  }
  Future<List<Map<String,dynamic>>> searchPatients(String q) async { if(q.trim().isEmpty)return patients; final s=q.toLowerCase(); return patients.where((x)=>(x['name']??'').toString().toLowerCase().contains(s)||(x['phone']??'').toString().contains(s)||(x['file_no']??'').toString().toLowerCase().contains(s)).toList(); }
}
